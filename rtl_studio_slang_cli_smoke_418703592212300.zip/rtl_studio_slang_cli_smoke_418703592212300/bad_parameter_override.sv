module parameter_leaf #(parameter int WIDTH = 8) (); endmodule
module bad_parameter_override;
  parameter_leaf #(.DOES_NOT_EXIST(4)) u_bad();
endmodule
