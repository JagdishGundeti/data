module multi_top(input logic [7:0] data_in, output logic [7:0] data_out);
  multi_leaf u_leaf(.a(data_in), .y(data_out));
endmodule
`ifdef PROJECT_FEATURE
module project_feature_marker; endmodule
`endif
