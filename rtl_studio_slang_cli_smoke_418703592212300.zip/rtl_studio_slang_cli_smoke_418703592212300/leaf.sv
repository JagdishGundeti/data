`include "width_defs.svh"
module multi_leaf(input logic [`DATA_WIDTH-1:0] a, output logic [`DATA_WIDTH-1:0] y);
  assign y = a;
endmodule
