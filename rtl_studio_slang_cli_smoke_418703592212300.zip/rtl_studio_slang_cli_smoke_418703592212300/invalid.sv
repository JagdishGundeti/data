module invalid(input logic a);
  assign a = ;
endmodule
