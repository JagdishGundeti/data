
module leaf #(parameter int WIDTH = 8, parameter int DEPTH = 2)
    (input logic [WIDTH-1:0] a, output logic [WIDTH-1:0] y);
  localparam int LOCKED = WIDTH + DEPTH;
  assign y = a;
endmodule

module smoke(input logic clk, output logic [15:0] result);
  leaf #(.WIDTH(16), .DEPTH(4)) u_named(.a(result), .y(result));
  leaf #(8, 2) u_positional(.a(clk), .y());
endmodule
